title: 剑指offer-二维数组中的查找
date: '2019-09-26 10:22:39'
updated: '2019-09-26 10:23:49'
tags: [剑指offer, 算法, 二维数组]
permalink: /articles/2019/09/26/1569464559176.html
---
![](https://img.hacpai.com/bing/20181205.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 二维数组中的查找
---  
[解题思路参考链接](https://github.com/CyC2018/CS-Notes/blob/master/notes/%E5%89%91%E6%8C%87%20Offer%20%E9%A2%98%E8%A7%A3%20-%203~9.md#4-%E4%BA%8C%E7%BB%B4%E6%95%B0%E7%BB%84%E4%B8%AD%E7%9A%84%E6%9F%A5%E6%89%BE)

---
## 题目描述

在一个二维数组中（每个一维数组的长度相同），每一行都按照从左到右递增的顺序排序，每一列都按照从上到下递增的顺序排序。请完成一个函数，输入这样的一个二维数组和一个整数，判断数组中是否含有该整数

---
## 解题思路
1. 方法一:暴力破解法
    > 利用两个循环，遍历数组中的每一个值，这样就可以判断是否存在  但这是o(n2)的算法，并不符合题意

2. 方法二：
    > 根据该数组的规律，从左到右递增从上到下递增，所以我们可以先从右上角开始，如果大于这一个数字，就可以直接查找下一行的数字，如果小于就一定在上一列之前，就继续查找上一列数字。这样就可以缩减区间


---

## 方法二 java代码

```java

public boolean Find(int target, int [][] array) {
   if(array==null||array.length==0||array[0].length==0)
    int row = array.length;
    int col = array[0].length;

    int r=0,c=col-1;
    while(r<row&&c>=0){
        if(array[r][c]==target) return true;
        else if(array[r][c]<target>){
            c--;
        }else{
            r++;
        }

    }
    return false;

}
```




