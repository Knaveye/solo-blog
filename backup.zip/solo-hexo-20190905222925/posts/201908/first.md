title: first
date: '2019-08-27 22:23:54'
updated: '2019-08-27 22:23:54'
tags: [java基础]
permalink: /articles/2019/08/27/1566915834230.html
---
![](https://img.hacpai.com/bing/20181031.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

- [x] 错题记录

---

-   1.一个接口可以继承多个接口
-   2.抽象类和接口中可以有方法体
-   
##### 1. 接口中默认方法前缀public abstract，而变量public static final
 > 1.   为什么是public：因为接口必然是要被实现的，如果不是public，这个属性就没有意义了； 
> 2.   为什么是static：因为如果不是static，那么由于每个类可以继承多个接口，那就会出现重名的情况； 
> 3.   为什么是final：这是为了体现java的开闭原则，因为接口是一种模板，既然是模板，那就对修改关闭，对扩展开放。 
##### 2.字符串子串数
> n个字符可设置的间隔为n+1个,所以子串为n(n+1)/2


##### 3. 切线 
> 平面切线 切成 n*(n+1)/2 部分
> 立体切线  （n*n*n+5*n+6）/6 

##### 4.return 和finally哪个先返回
>1.  finally语句在return语句之前执行!其实当程序执行到try语句中的return时候，先会将返回结果存储到临时栈中，再去执行finally的语句。
>2. 如果fanily的没有return的话，即使再怎么赋值返回值，也不会改变临时栈的值

#### 5.java表达式转型规则，由低到高转换：
>1. byte，short，char的值被提升为int型
>2. 如果有一个操作数是long，计算结果是long型
>3. 被final修饰的变量不会自动改变类型，当2个final修饰相操作，根据左边变量的类型而转化

#### 6. java堆
> java的堆是jvm管理的最大的内存空间，主要用来存放各种类的实例对象，主要分为新生代和老年代。新生代划分为Eden/From Survivor/to Survivor

#### 7. 类初始化的时候
> 静态成员变量或静态代码块>main方法>非静态成员变量或非静态代码块>构造方法

#### 8. static定义的变量，不管多少个类调用，使用的都是同一个
#### 9. 引用
<html>
<div>  <div>   <span>四种引用类型</span>  </div>  <div>   <span>JDK1.2 之前，一个对象只有“已被引用”和"未被引用"两种状态，这将无法描述某些特殊情况下的对象，比如，当内存充足时需要保留，而内存紧张时才需要被抛弃的一类对象。</span>  </div>  <div>   <span>所以在 JDK.1.2 之后，Java 对引用的概念进行了扩充，将引用分为了：强引用（Strong Reference）、软引用（Soft Reference）、弱引用（Weak Reference）、虚引用（Phantom Reference）4 种，这 4 种引用的强度依次减弱。</span>  </div>  <div>   <span>一，强引用</span>  </div>  <div>   <span>Object</span><span> obj = </span><span>new</span><span> </span><span>Object</span><span>(); </span><span>//只要obj还指向Object对象，Object对象就不会被回收</span><span> obj = </span><span>null</span><span>; </span><span>//手动置null</span>  </div>  <div>   <span>只要强引用存在，垃圾回收器将永远不会回收被引用的对象，哪怕内存不足时，JVM也会直接抛出OutOfMemoryError，不会去回收。如果想中断强引用与对象之间的联系，可以显示的将强引用赋值为null，这样一来，JVM就可以适时的回收对象了</span>  </div>  <div>   <span>二，软引用</span>  </div>  <div>   <span>软引用是用来描述一些非必需但仍有用的对象。</span><span>在内存足够的时候，软引用对象不会被回收，只有在内存不足时，系统则会回收软引用对象，如果回收了软引用对象之后仍然没有足够的内存，才会抛出内存溢出异常</span><span>。这种特性常常被用来实现缓存技术，比如网页缓存，图片缓存等。</span>  </div>  <div>   <span>在 JDK1.2 之后，用java.lang.ref.SoftReference类来表示软引用。</span>  </div>  <div>   <span>三，弱引用</span>  </div>  <div>   <span>弱引用的引用强度比软引用要更弱一些，</span><span>无论内存是否足够，只要 JVM 开始进行垃圾回收，那些被弱引用关联的对象都会被回收</span><span>。在 JDK1.2 之后，用 java.lang.ref.WeakReference 来表示弱引用。</span>  </div>  <div>   <span>四，虚引用</span>  </div>  <div>   <span>虚引用是最弱的一种引用关系，如果一个对象仅持有虚引用，那么它就和没有任何引用一样，它随时可能会被回收，在 JDK1.2 之后，用 PhantomReference 类来表示，通过查看这个类的源码，发现它只有一个构造函数和一个 get() 方法，而且它的 get() 方法仅仅是返回一个null，也就是说将永远无法通过虚引用来获取对象，虚引用必须要和 ReferenceQueue 引用队列一起使用。</span>  </div> </div>

</html>


